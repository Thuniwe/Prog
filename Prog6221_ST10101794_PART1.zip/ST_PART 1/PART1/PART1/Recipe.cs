﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PART1
{
    class Recipe
    {
        //Declaring variables and arrays
        private int numberOfIngredients;
        private string[] ingNames;
        private double[] ingQuantity;
        private string[] ingMeasurement;
        private int numberOfSteps;
        private string[] steps;

        public void EnterRecipe()//creating a method to get user input
        {
            //Using a try catch to handle any errors
            try
            {
                //Getting user input
                Console.Write("Enter the number of ingredients: ");
                numberOfIngredients = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            //initiating the arrays declared
            ingNames = new string[numberOfIngredients];
            ingQuantity = new double[numberOfIngredients];
            ingMeasurement = new string[numberOfIngredients];

            try //using try catch to handle any errors from the user
            {
                //Create a for loop to get the name,quantity, and measurement
                for (int i = 0; i < numberOfIngredients; i++)
                {
                    Console.Write($"Enter the name of ingredient {i + 1}: ");
                    ingNames[i] = Console.ReadLine(); //storing in the arrays declared

                    Console.Write($"Enter the quantity of ingredient {i + 1}: ");
                    ingQuantity[i] = double.Parse(Console.ReadLine()); //storing in the arrays declared

                    Console.Write($"Enter the unit of measurement for ingredient {i + 1}: ");
                    ingMeasurement[i] = Console.ReadLine(); //storing in the arrays declared
                }

                Console.Write("Enter the number of steps: ");
                numberOfSteps = Convert.ToInt32(Console.ReadLine());

                steps = new string[numberOfSteps];

                for (int i = 0; i < numberOfSteps; i++)//using a for loop to get the steps
                {
                    Console.Write($"Enter step {i + 1}: ");
                    steps[i] = Console.ReadLine();
                }
            }
            catch (Exception j)
            {
                Console.WriteLine(j.Message);
            }

            Console.WriteLine();
            Console.WriteLine("Recipe entered successfully!");
            Console.WriteLine();
        }
        
        public void DisplayRecipe() //creating a method to display
        {
            Console.WriteLine();
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\tRECIPE");
            Console.WriteLine("---------------------------------");

            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"{ingQuantity[i]} {ingMeasurement[i]} of {ingNames[i]}");
            }

            Console.WriteLine();

            for (int i = 0; i < numberOfSteps; i++)
            {
                Console.WriteLine($"Step{i + 1}. {steps[i]}");
            }

            Console.WriteLine();
            Console.WriteLine("---------------------------------");
        }

        public void ScaleRecipe(double factor) //creating a method to scale the recipe
        {
            //creating an array to store the copy of the ingQuantity data
            double[] ingQuan = new double[numberOfIngredients];
            ingQuan = (double[])ingQuantity.Clone();
            
            for (int i = 0; i < numberOfIngredients; i++)
            {
                ingQuan[i] *= factor;
            }
            //displaying the scaled recipe
            Console.WriteLine($"Recipe scaled by {factor}x successfully!");
            Console.WriteLine();
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\tRECIPE");
            Console.WriteLine("---------------------------------");

            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"{ingQuan[i]} {ingMeasurement[i]} of {ingNames[i]}");
            }

            Console.WriteLine();

            for (int i = 0; i < numberOfSteps; i++)
            {
                Console.WriteLine($"Step{i + 1}. {steps[i]}");
            }
            Console.WriteLine("---------------------------------");

            Console.WriteLine();
        }

        public void ResetQuantities() //creating a method to reset
        {
            Console.WriteLine("Resetting quantities to original values");
            Console.WriteLine();

            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"{ingQuantity[i]} {ingMeasurement[i]} of {ingNames[i]}");
            }
            Console.WriteLine();
        }

        public void ClearAllData() //creating a method to clear
        {
            numberOfIngredients = 0;
            ingNames = null;
            ingQuantity = null;
            ingMeasurement = null;
            numberOfSteps = 0;
            steps = null;

            Console.WriteLine("Recipe cleared successfully!");
        }
    }
}
